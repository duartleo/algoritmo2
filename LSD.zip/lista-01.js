let alunos = ["maria", "joao", "Ana", "Pedro"];
console.log(alunos);
console.log(alunos[2]);
console.log(alunos.length);
console.table(alunos);
(alunos[1] = 'adriana');
console.table(alunos);