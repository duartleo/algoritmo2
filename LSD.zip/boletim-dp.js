// boletim escolar
let boletim = [[8, 7, 9, 3],[4, 5, 8, 6]];
console.log(boletim);
console.log(boletim[1][2]);
console.table(boletim);
boletim[1][2] = 10;
console.table(boletim);