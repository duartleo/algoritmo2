let sequencia = [7, 5, 1, 8, 3];
sequencia.sort((b, a) => a - b);
console.log(sequencia);